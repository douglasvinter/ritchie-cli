# Ritchie Formula

## Command

```bash
rit testing without-dockerfile
```

## Description

Formula description
