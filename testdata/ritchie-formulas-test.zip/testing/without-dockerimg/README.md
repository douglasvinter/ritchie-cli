# Ritchie Formula

## Command

```bash
rit testing without-dockerimg
```

## Description

Formula description
