# Ritchie Formula

## Command

```bash
rit testing formula
```

## Description

Formula description
